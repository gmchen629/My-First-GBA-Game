# Hero VS Dragon

## How To Play

- Press the 'Enter' to start.
- When the game starts, 5 seconds to move the hero to the target monster (the black hole!).
  - Use arrow keys to move the hero
    - UP arrow: moves the hero up
    - DOWN arrow: moves the hero down
    - LEFT arrow: moves the hero to the left
    - RIGHT arrow: moves the hero to the right

- Notes:
  - If you get the hero to the target monster before 5 seconds (see the timer), you WIN the game.
  - Otherwise, if you take too long or you get to the small monster (green monster), you LOSE.
  - Anytime press the 'Backspace' to reset the game.