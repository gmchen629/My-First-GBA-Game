/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=35x35 monster_small monster_small.png 
 * Time-stamp: Monday 07/18/2022, 16:55:58
 * 
 * Image Information
 * -----------------
 * monster_small.png 35@35
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef MONSTER_SMALL_H
#define MONSTER_SMALL_H

extern const unsigned short monster_small[1225];
#define MONSTER_SMALL_SIZE 2450
#define MONSTER_SMALL_LENGTH 1225
#define MONSTER_SMALL_WIDTH 35
#define MONSTER_SMALL_HEIGHT 35

#endif

