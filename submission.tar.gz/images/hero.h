/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=35x35 hero hero.png 
 * Time-stamp: Monday 07/18/2022, 02:28:57
 * 
 * Image Information
 * -----------------
 * hero.png 35@35
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef HERO_H
#define HERO_H

extern const unsigned short hero[1225];
#define HERO_SIZE 2450
#define HERO_LENGTH 1225
#define HERO_WIDTH 35
#define HERO_HEIGHT 35

#endif

