/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=240x160 loss loss.png 
 * Time-stamp: Monday 07/18/2022, 02:57:44
 * 
 * Image Information
 * -----------------
 * loss.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef LOSS_H
#define LOSS_H

extern const unsigned short loss[38400];
#define LOSS_SIZE 76800
#define LOSS_LENGTH 38400
#define LOSS_WIDTH 240
#define LOSS_HEIGHT 160

#endif

