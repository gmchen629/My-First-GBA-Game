/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=35x35 monster monster.png 
 * Time-stamp: Monday 07/18/2022, 02:37:01
 * 
 * Image Information
 * -----------------
 * monster.png 35@35
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef MONSTER_H
#define MONSTER_H

extern const unsigned short monster[1225];
#define MONSTER_SIZE 2450
#define MONSTER_LENGTH 1225
#define MONSTER_WIDTH 35
#define MONSTER_HEIGHT 35

#endif

